// pages/main/main.js
Page({
  data: {
    currentTab: 'report'
  },
  switchTab: function(e) {
    this.setData({
      currentTab: e.currentTarget.dataset.tab
    })
  },
  navigateTo: function(e) {
    wx.navigateTo({
      url: '../' + e.currentTarget.dataset.page + '/' + e.currentTarget.dataset.page
    })
  }
})
