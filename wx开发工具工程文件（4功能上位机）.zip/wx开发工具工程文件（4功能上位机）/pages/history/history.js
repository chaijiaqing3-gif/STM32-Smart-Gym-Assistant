// pages/history/history.js
Page({
  data: {
    historyList: [
      { id: 1, date: '2023-05-01', pressure: '80', steps: '8000' },
      { id: 2, date: '2023-05-02', pressure: '75', steps: '9500' },
      { id: 3, date: '2023-05-03', pressure: '90', steps: '7800' }
    ]
  },
  viewDetail: function(e) {
    const id = e.currentTarget.dataset.id
    wx.showToast({
      title: '查看详情：' + id,
      icon: 'none'
    })
  }
})
