// pages/weather/weather.js
Page({
  data: {
    weatherData: {
      temperature: '25°C',
      condition: '晴',
      humidity: '40%',
      windSpeed: '3m/s'
    },
    trainingAdvice: {
      suggestion: '建议训练',
      notes: '今天天气不错，可以进行室外运动。请注意防晒，带好遮阳帽和防晒露。'
    }
  }
})
