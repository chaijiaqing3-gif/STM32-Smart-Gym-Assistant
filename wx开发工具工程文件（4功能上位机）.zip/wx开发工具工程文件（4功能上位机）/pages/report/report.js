// pages/report/report.js
Page({
  data: {
    chartData: {}
  },
  onLoad: function () {
    this.updateChart()
    // 每10秒更新一次图表
    setInterval(this.updateChart, 10000)
  },
  updateChart: function () {
    // 模拟数据
    const time = new Date().toLocaleTimeString()
    const pressure = Math.floor(Math.random() * 60)
    const steps = Math.floor(Math.random() * 5)
    this.setData({
      chartData: {
        categories: [time],
        series: [
          { name: '压力', data: [pressure] },
          { name: '步数', data: [steps] }
        ]
      }
    })
  },
  saveReport: function () {
    wx.showToast({
      title: '报告已保存',
      icon: 'success'
    })
  }
})
