// pages/login/login.js
Page({
  data: {
    username: '',
    password: ''
  },
  // 输入用户名
  inputUsername: function(e) {
    this.setData({
      username: e.detail.value
    })
  },
  // 输入密码
  inputPassword: function(e) {
    this.setData({
      password: e.detail.value
    })
  },
  // 登录
  login: function() {
    if (this.data.username && this.data.password) {
      // 这里应该有登录验证逻辑，现在我们直接跳转到主页
      wx.navigateTo({
        url: '../main/main',
      })
    } else {
      wx.showToast({
        title: '用户名和密码不能为空',
        icon: 'none'
      })
    }
  },
  // 重置
  reset: function() {
    this.setData({
      username: '',
      password: ''
    })
  },
  // 注册
  register: function() {
    wx.showToast({
      title: '注册功能暂未开放',
      icon: 'none'
    })
  }
})
