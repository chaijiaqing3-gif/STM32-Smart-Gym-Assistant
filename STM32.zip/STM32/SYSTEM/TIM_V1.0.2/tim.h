#ifndef _TEM_H_
#define _TEM_H_

#include <stdint.h>
#include "stm32f10x_tim.h"

#define TIM1_enable	1		//�Ƿ��������ʱ����1����  0�ر�
#define TIM2_enable	1
#define TIM3_enable	1
#define TIM4_enable	1


#if TIM1_enable 
void tim1_init(uint16_t Pre,uint16_t Psc);
#endif


#if TIM2_enable 
void tim2_init(uint16_t Pre,uint16_t Psc);
#endif


#if TIM3_enable 
void tim3_init(uint16_t Pre,uint16_t Psc);
#endif


#if TIM4_enable 
void tim4_init(uint16_t Pre,uint16_t Psc);
#endif


void tim1_IRQ(void);
void tim2_IRQ(void);
void tim3_IRQ(void);
void tim4_IRQ(void);



#ifndef WEAK				//WEAK�������壬��һ����Ϊ�˸���ͬ�ı�������
#	ifdef __CC_ARM
#		define WEAK __weak
#	elif defined(__IAR_SYSTEMS_ICC__)
#		define WEAK __weak
#	elif defined(__GNUC__)
#		define WEAK __attribute__((weak))
#	elif defined(__ADSPBLACKFIN__)
#		define WEAK __attribute__((weak))
#	elif defined(_MSC_VER)
#		define WEAK
#	elif defined(__TI_COMPILER_VERSION__)
#		define WEAK
#	else
#		error not supported tool chain
#	endif
#endif

#endif
