#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED PCout(15) = !PCin(15)

#define OUT1 PCout(13) 
#define BEEP PCout(14)
#define OUT3 PCout(15)

void LED_Init(void);//��ʼ��

		 				    
#endif
