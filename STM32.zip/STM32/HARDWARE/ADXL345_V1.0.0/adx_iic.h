#ifndef __IIC_H
#define __IIC_H

#include "stm32f10x.h"

/* ��ʱʹ�õ�IO�� */
#define IIC_SDA_IN()  {GPIOB->CRL &= 0XFFFFFF0F;GPIOB->CRL |= 8 << 4;\
GPIOB->BSRR = 1 << 1;} //����(����)
#define IIC_SDA_OUT() {GPIOB->CRL &= 0XFFFFFF0F;GPIOB->CRL |= 3 << 4;} //�������

#define IIC_SDA_SET {GPIOB->BSRR = 1 << 1;}
#define IIC_SDA_CLR {GPIOB->BRR = 1 << 1;}
#define IIC_SDA     (GPIOB->IDR & (1 << 1))
#define IIC_SCL_SET {GPIOB->BSRR = 1 << 0;}
#define IIC_SCL_CLR {GPIOB->BRR = 1 << 0;}

/* ����ȫ�ֺ��� */
void IIC_Config(void);
void IIC_Start_adx(void);
void IIC_Stop_adx(void);
void IIC_SendData(uint8_t dat);
uint8_t IIC_ReceiveData(uint8_t ack);
int8_t IIC_WaitAck(void);




























#endif
